<?php

class YoghBL_Customizer_Control_Links extends WP_Customize_Control {

	public $type = 'yoghbiolinks_links';

	public function render_content() {}

	public function content_template() {
		$add_items = __( 'Add Items' );
		?>
		<p class="new-menu-item-invitation">
			<?php
			printf(
				/* translators: %s: "Add Items" button text. */
				__( 'Time to add some links! Click &#8220;%s&#8221; to start putting pages, categories, and custom links in your menu. Add as many things as you would like.' ),
				$add_items
			);
			?>
		</p>
		<div class="customize-control-nav_menu-buttons">
			<button type="button" class="button add-new-menu-item" aria-label="<?php esc_attr_e( 'Add or remove menu items' ); ?>" aria-expanded="false" aria-controls="available-menu-items">
				<?php echo $add_items; ?>
			</button>
			<button type="button" class="button-link reorder-toggle" aria-label="<?php esc_attr_e( 'Reorder menu items' ); ?>" aria-describedby="reorder-items-desc-yoghbiolinks_links">
				<span class="reorder"><?php _e( 'Reorder' ); ?></span>
				<span class="reorder-done"><?php _e( 'Done' ); ?></span>
			</button>
		</div>
		<p class="screen-reader-text" id="reorder-items-desc-yoghbiolinks_links"><?php _e( 'When in reorder mode, additional controls to reorder menu items will be available in the items list above.' ); ?></p>
		<?php
	}

	public function json() {
		$exported            = parent::json();
		$exported['menu_id'] = 'yoghbiolinks_links';

		return $exported;
	}
}
